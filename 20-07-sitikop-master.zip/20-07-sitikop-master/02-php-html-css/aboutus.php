<!DOCTYPE html>
<html lang="en">

<head>
  <title>About Us</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="aboutus.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<nav class="navbar navbar-expand-md navbar-black bg-black">
    <div class="navbar-collapse collapse w-100 order-1 order-md-0 dual-collapse2">
        <a class="navbar-brand title" href="#">22.</a>
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link" href="homepagestartphprepair.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="movie.php">Movies</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="cinema.pho">Cinema</a>
            </li>
            <col-md-3>
            <li class="nav-item">
                <a class="nav-link" href="AboutUsPage.php">About Us</a>
            </li>
            <div class="line2">
                <td class="line2">
                </td>
            </div>
        </col-md-3>
        </ul>
    </div>
    <div class="navbar-collapse collapse w-100 order-3 dual-collapse2">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link" href="#"><span class="fa fa-search" style="font-size:24px"></span></a>
            </li>
            <li class="nav-item">
                <button type="button" class="btn btn-dark" style="border-color:silver;"><span class="fa fa-bars"></span></button>
            </li>
        </ul>
    </div>
</nav>
<br>
<br>
<br>
<br>
<br>
<center>
<div>
    <h1>What are we?</h1>
<br/>
<p>Pilem22, is a platform that facilities you to order the latest movie tikets,<br/>
so you don't have to bother going to the nearest cinema just to order movie tickets. </p>
</center>
<br>
    <col-md-3>
<div class="line">
    <td class="line">
</col-md-3>
    </td>
</div>
<br>
</div>
<br>
<center>
<h2> What makes us believe that<br/>
    we can serve you well?</h2>
<br>
<p2>Of course, we believe with our platform, we make it esay for you to access the films that we broadcast,<br/>
    and they are the latest films, so you don't have to worry about that. </p2>
</center>
</body>
<br>
<br>
<br>
<footer>
<div>
    <br>
    <br>
    <br>
    <br>
    <br>
    <p><input type="button" class="btn" value="Instagram">
    <input type="button" class="btn" value="Facebook">
    <input type="button" class="btn" value="Twitter"></p>
</div> 
</footer>
</html>